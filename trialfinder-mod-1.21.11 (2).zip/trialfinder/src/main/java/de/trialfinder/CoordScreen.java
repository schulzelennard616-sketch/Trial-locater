package de.trialfinder;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

/** Waypoint per Koordinaten-Eingabe. Funktioniert auch auf Servern, weil alles nur auf dem Client laeuft. */
public class CoordScreen extends Screen {
	private final Screen parent;
	private TextFieldWidget xField;
	private TextFieldWidget yField;
	private TextFieldWidget zField;
	private String error = "";

	public CoordScreen(Screen parent) {
		super(Text.literal("Waypoint per Koordinaten"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		int cx = this.width / 2;
		int y = this.height / 2 - 20;

		xField = new TextFieldWidget(this.textRenderer, cx - 100, y, 60, 20, Text.literal("X"));
		yField = new TextFieldWidget(this.textRenderer, cx - 30, y, 60, 20, Text.literal("Y"));
		zField = new TextFieldWidget(this.textRenderer, cx + 40, y, 60, 20, Text.literal("Z"));
		xField.setPlaceholder(Text.literal("X"));
		yField.setPlaceholder(Text.literal("Y (optional)"));
		zField.setPlaceholder(Text.literal("Z"));
		xField.setMaxLength(40);
		yField.setMaxLength(12);
		zField.setMaxLength(12);

		addDrawableChild(xField);
		addDrawableChild(yField);
		addDrawableChild(zField);

		addDrawableChild(ButtonWidget.builder(Text.literal("Waypoint setzen"), b -> apply())
				.dimensions(cx - 100, y + 30, 200, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Zur\u00fcck"), b -> close())
				.dimensions(cx - 100, y + 54, 200, 20).build());
	}

	private void apply() {
		try {
			String xs = xField.getText().trim();
			String ys = yField.getText().trim();
			String zs = zField.getText().trim();

			// Alles in das X-Feld eingefuegt, z.B. "120 -40 350" oder "120, -40, 350"
			String[] parts = xs.split("[\\s,]+");
			if (parts.length == 3 && ys.isEmpty() && zs.isEmpty()) {
				xs = parts[0];
				ys = parts[1];
				zs = parts[2];
			}

			int x = Integer.parseInt(xs);
			int z = Integer.parseInt(zs);
			int y = ys.isEmpty() ? (this.client.player != null ? this.client.player.getBlockY() : 64) : Integer.parseInt(ys);

			WaypointState.set(new BlockPos(x, y, z), "Waypoint");
			this.client.setScreen(null);
		} catch (NumberFormatException e) {
			error = "Bitte ganze Zahlen eingeben (X und Z sind Pflicht).";
		}
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		int cx = this.width / 2;
		int y = this.height / 2 - 20;
		context.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, y - 30, 0xFFFFFFFF);
		context.drawCenteredTextWithShadow(this.textRenderer,
				Text.literal("Tipp: \"120 -40 350\" ins erste Feld einf\u00fcgen"), cx, y - 14, 0xFFAAAAAA);
		if (!error.isEmpty()) {
			context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(error), cx, y + 82, 0xFFFF5555);
		}
	}

	@Override
	public void close() {
		this.client.setScreen(this.parent);
	}
}
