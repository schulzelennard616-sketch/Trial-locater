package de.trialfinder;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

public class FinderScreen extends Screen {
	private static final SearchSession SESSION = new SearchSession();
	private volatile boolean busy;

	public FinderScreen() {
		super(Text.literal("Trial Chamber Finder"));
	}

	public static void resetSession() {
		SESSION.reset();
	}

	@Override
	protected void init() {
		int x = this.width / 2 - 100;
		int y = this.height / 2 + 10;

		addDrawableChild(ButtonWidget.builder(Text.literal("Waypoint erstellen"), b -> createWaypoint())
				.dimensions(x, y, 200, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Einstellungen"),
						b -> this.client.setScreen(new SettingsScreen(this)))
				.dimensions(x, y + 24, 200, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Weitersuchen"), b -> search(true))
				.dimensions(x, y + 48, 200, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Koordinaten eingeben"),
						b -> this.client.setScreen(new CoordScreen(this)))
				.dimensions(x, y + 72, 200, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Schlie\u00dfen"), b -> close())
				.dimensions(x, y + 96, 200, 20).build());

		if (SESSION.result == null && SESSION.status.isEmpty() && !busy) {
			search(false);
		}
	}

	private void createWaypoint() {
		ChamberFinder.Chamber chamber = SESSION.result;
		if (chamber == null) {
			return;
		}
		if (!chamber.itemChests().isEmpty()) {
			WaypointState.set(chamber.itemChests().get(0), "Trident-Kiste", false);
		} else {
			WaypointState.set(chamber.center(), "Trial Chamber", SESSION.approximate);
		}
		close();
	}

	private void search(boolean continueSearch) {
		MinecraftClient mc = this.client;
		if (mc.player == null || mc.world == null || busy) {
			return;
		}
		if (!continueSearch) {
			SESSION.reset();
		}
		if (mc.world.getRegistryKey() != World.OVERWORLD) {
			SESSION.status = "Trial Chambers gibt es nur in der Oberwelt.";
			return;
		}

		BlockPos origin = mc.player.getBlockPos();
		IntegratedServer server = mc.getServer();

		// Multiplayer: reine Seed-Berechnung ab der aktuellen Position
		if (server == null) {
			SESSION.stepSeed(FinderSettings.seed, origin);
			return;
		}

		// Einzelspieler: echte Abfrage ueber den integrierten Server
		busy = true;
		SESSION.status = "Suche l\u00e4uft ...";
		RegistryKey<World> worldKey = mc.world.getRegistryKey();
		boolean requireItem = FinderSettings.requireTrident;

		server.execute(() -> {
			try {
				ServerWorld world = server.getWorld(worldKey);
				if (world != null) {
					SESSION.step(world, origin, requireItem);
				}
			} catch (Exception e) {
				TrialFinderClient.LOGGER.error("Suche fehlgeschlagen", e);
				SESSION.status = "Fehler: " + e;
			} finally {
				busy = false;
			}
		});
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);

		List<String> lines = new ArrayList<>();
		lines.add(SESSION.status);

		Long seed = SESSION.worldSeed;
		if (seed != null) {
			if (SESSION.approximate) {
				lines.add("Seed (Einstellung): " + seed);
			} else {
				lines.add(seed == TrialFinderClient.TARGET_SEED ? "Seed: passt (" + seed + ")" : "Seed weicht ab: " + seed);
			}
		}
		if (!SESSION.selfTest.isEmpty()) {
			lines.add(SESSION.selfTest);
		}

		ChamberFinder.Chamber chamber = SESSION.result;
		BlockPos origin = SESSION.searchOrigin;
		if (chamber != null) {
			BlockPos c = chamber.center();
			String yText = SESSION.approximate ? "Y ca. " + c.getY() + " (gesch\u00e4tzt)" : String.valueOf(c.getY());
			lines.add("Chamber: " + c.getX() + ", " + yText + ", " + c.getZ());
			if (origin != null) {
				double dx = c.getX() - origin.getX();
				double dz = c.getZ() - origin.getZ();
				lines.add("Entfernung: " + (int) Math.sqrt(dx * dx + dz * dz) + " Bl\u00f6cke");
			}
			if (SESSION.approximate) {
				lines.add("Kisten-Filter gibt es nur im Einzelspieler.");
			} else if (chamber.scanned()) {
				lines.add("Vaults: " + chamber.vaults() + "  |  Trident-Kisten: " + chamber.itemChests().size());
				if (!chamber.itemChests().isEmpty()) {
					BlockPos k = chamber.itemChests().get(0);
					lines.add("Kiste: " + k.getX() + ", " + k.getY() + ", " + k.getZ());
				}
			}
		}

		int y = this.height / 2 - 84;
		context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, y - 20, 0xFFFFFFFF);
		for (String line : lines) {
			context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(line), this.width / 2, y, 0xFFFFFFFF);
			y += 12;
		}
	}

	@Override
	public boolean shouldPause() {
		return false;
	}
}
