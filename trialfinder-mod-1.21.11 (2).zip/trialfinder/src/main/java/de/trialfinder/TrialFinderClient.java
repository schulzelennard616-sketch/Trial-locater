package de.trialfinder;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TrialFinderClient implements ClientModInitializer {
	public static final String MOD_ID = "trialfinder";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	/** Ziel-Seed, fuer den die Mod gedacht ist (nur fuer die Seed-Pruefung im Menue). */
	public static final long TARGET_SEED = 7356637963557968760L;

	private static KeyBinding openMenuKey;

	@Override
	public void onInitializeClient() {
		KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));
		openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.trialfinder.open_menu",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_K,
				category));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openMenuKey.wasPressed()) {
				if (client.world != null && client.currentScreen == null) {
					client.setScreen(new FinderScreen());
				}
			}
		});

		HudRenderCallback.EVENT.register(WaypointHud::render);
	}
}
