package de.trialfinder;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class SettingsScreen extends Screen {
	private final Screen parent;

	public SettingsScreen(Screen parent) {
		super(Text.literal("Einstellungen"));
		this.parent = parent;
	}

	private static Text filterLabel() {
		return Text.literal("Nur Chambers mit Trident-Kiste: " + (FinderSettings.requireTrident ? "AN" : "AUS"));
	}

	@Override
	protected void init() {
		int x = this.width / 2 - 120;
		int y = this.height / 2 - 40;

		addDrawableChild(ButtonWidget.builder(filterLabel(), b -> {
			FinderSettings.requireTrident = !FinderSettings.requireTrident;
			b.setMessage(filterLabel());
			FinderScreen.resetSession();
		}).dimensions(x, y, 240, 20).build());

		TextFieldWidget seedField = new TextFieldWidget(this.textRenderer, x, y + 44, 240, 20, Text.literal("Seed"));
		seedField.setMaxLength(24);
		seedField.setText(String.valueOf(FinderSettings.seed));
		seedField.setChangedListener(text -> {
			try {
				FinderSettings.seed = Long.parseLong(text.trim());
				FinderScreen.resetSession();
			} catch (NumberFormatException ignored) {
				// ungueltige Eingabe: alter Seed bleibt aktiv
			}
		});
		addDrawableChild(seedField);

		addDrawableChild(ButtonWidget.builder(Text.literal("Zur\u00fcck"), b -> this.client.setScreen(this.parent))
				.dimensions(x, y + 76, 240, 20).build());
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		int x = this.width / 2;
		int y = this.height / 2 - 40;
		context.drawCenteredTextWithShadow(this.textRenderer, this.title, x, y - 24, 0xFFFFFFFF);
		context.drawCenteredTextWithShadow(this.textRenderer,
				Text.literal("Seed f\u00fcr Server-Berechnung (im Einzelspieler z\u00e4hlt der Welt-Seed):"),
				x, y + 30, 0xFFAAAAAA);
	}

	@Override
	public void close() {
		this.client.setScreen(this.parent);
	}
}
