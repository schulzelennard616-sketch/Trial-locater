package de.trialfinder;

import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockBox;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.World;

import java.util.List;

/** Merkt sich Kandidatenliste und Ergebnis, damit "Weitersuchen" dort fortsetzt, wo die Suche stehen blieb. */
public final class SearchSession {
	public volatile ChamberFinder.Chamber result;
	public volatile String status = "";
	public volatile Long worldSeed;
	public volatile BlockPos searchOrigin;
	/** true, wenn das Ergebnis nur aus dem Seed berechnet wurde (Y geschaetzt, Kisten unbekannt). */
	public volatile boolean approximate;
	public volatile String selfTest = "";

	private List<ChunkPos> candidates;
	private int index;

	public synchronized void reset() {
		result = null;
		candidates = null;
		index = 0;
		status = "";
		selfTest = "";
		approximate = false;
		worldSeed = null;
	}

	/** Einzelspieler: nutzt den integrierten Server. Laeuft auf dem Server-Thread. */
	public synchronized void step(ServerWorld world, BlockPos origin, boolean requireItem) {
		if (world.getRegistryKey() != World.OVERWORLD) {
			status = "Trial Chambers gibt es nur in der Oberwelt.";
			return;
		}
		approximate = false;
		worldSeed = world.getSeed();
		searchOrigin = origin;

		if (candidates == null) {
			candidates = ChamberFinder.candidates(world, origin, FinderSettings.searchRadiusRegions);
			index = 0;

			// Selbsttest: stimmt die reine Seed-Berechnung mit dem Spiel ueberein?
			List<ChunkPos> mine = SeedLocator.nearest(world.getSeed(), origin, FinderSettings.searchRadiusRegions);
			int n = Math.min(5, Math.min(mine.size(), candidates.size()));
			boolean ok = n > 0 && mine.subList(0, n).equals(candidates.subList(0, n));
			selfTest = ok ? "Seed-Rechner: OK (stimmt mit dem Spiel \u00fcberein)" : "Seed-Rechner: weicht ab!";
		}

		int scanned = 0;
		while (index < candidates.size() && scanned < FinderSettings.maxChambersPerRun) {
			ChunkPos chunk = candidates.get(index++);
			ChamberFinder.Chamber chamber = ChamberFinder.inspect(world, chunk, requireItem, ChamberFinder.wantedItem());
			if (chamber == null) {
				continue;
			}
			scanned++;
			if (!requireItem || !chamber.itemChests().isEmpty()) {
				result = chamber;
				status = requireItem ? "Chamber mit Trident-Kiste gefunden." : "N\u00e4chste Chamber gefunden.";
				return;
			}
		}

		result = null;
		if (index >= candidates.size()) {
			status = "Im Suchradius nichts Passendes gefunden.";
		} else {
			status = scanned + " Chambers gepr\u00fcft, keine passt. \"Weitersuchen\" klicken.";
		}
	}

	/** Multiplayer: reine Seed-Berechnung ab der aktuellen Position. Laeuft auf dem Client-Thread. */
	public synchronized void stepSeed(long seed, BlockPos origin) {
		approximate = true;
		worldSeed = seed;
		searchOrigin = origin;
		selfTest = "";

		if (candidates == null) {
			candidates = SeedLocator.nearest(seed, origin, FinderSettings.searchRadiusRegions);
			index = 0;
		}
		if (index >= candidates.size()) {
			result = null;
			status = "Keine weitere Chamber im Suchradius.";
			return;
		}

		ChunkPos chunk = candidates.get(index++);
		BlockPos center = new BlockPos(chunk.getStartX() + 8, SeedLocator.APPROX_Y, chunk.getStartZ() + 8);
		result = new ChamberFinder.Chamber(new BlockBox(center), center, false, 0, List.of());
		status = "Chamber aus Seed berechnet (Nr. " + index + " ab deiner Position).";
	}
}
