package de.trialfinder;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.entity.LootableContainerBlockEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.loot.context.LootWorldContext;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.structure.StructureStart;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockBox;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.gen.chunk.placement.RandomSpreadStructurePlacement;
import net.minecraft.world.gen.chunk.placement.StructurePlacement;
import net.minecraft.world.gen.chunk.placement.StructurePlacementCalculator;
import net.minecraft.world.gen.structure.Structure;
import net.minecraft.world.gen.structure.StructureKeys;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * Sucht Trial Chambers ueber die Struktur-Platzierungsdaten des Spiels (kein hartkodierter Seed-Algorithmus)
 * und prueft optional die Kisten per Loot-Tabelle + gespeichertem Loot-Seed.
 * Laeuft auf dem Server-Thread des integrierten Servers (Einzelspieler).
 */
public final class ChamberFinder {
	private ChamberFinder() {}

	public record Chamber(BlockBox box, BlockPos center, boolean scanned, int vaults, List<BlockPos> itemChests) {}

	/** Kandidaten-Startchunks aller Trial Chambers im Umkreis, nach Entfernung sortiert. */
	public static List<ChunkPos> candidates(ServerWorld world, BlockPos origin, int radiusRegions) {
		StructurePlacementCalculator calculator = world.getChunkManager().getStructurePlacementCalculator();
		Registry<Structure> registry = world.getRegistryManager().getOrThrow(RegistryKeys.STRUCTURE);
		RegistryEntry<Structure> entry = registry.getOrThrow(StructureKeys.TRIAL_CHAMBERS);

		List<ChunkPos> result = new ArrayList<>();
		int originChunkX = origin.getX() >> 4;
		int originChunkZ = origin.getZ() >> 4;

		for (StructurePlacement placement : calculator.getPlacements(entry)) {
			if (!(placement instanceof RandomSpreadStructurePlacement spread)) {
				continue;
			}
			int spacing = spread.getSpacing();
			int regionX = Math.floorDiv(originChunkX, spacing);
			int regionZ = Math.floorDiv(originChunkZ, spacing);
			for (int dx = -radiusRegions; dx <= radiusRegions; dx++) {
				for (int dz = -radiusRegions; dz <= radiusRegions; dz++) {
					ChunkPos start = spread.getStartChunk(
							calculator.getStructureSeed(),
							(regionX + dx) * spacing,
							(regionZ + dz) * spacing);
					if (placement.shouldGenerate(calculator, start.x, start.z)) {
						result.add(start);
					}
				}
			}
		}

		result.sort(Comparator.comparingDouble(cp -> {
			double ddx = (cp.x << 4) + 8 - origin.getX();
			double ddz = (cp.z << 4) + 8 - origin.getZ();
			return ddx * ddx + ddz * ddz;
		}));
		return result;
	}

	/**
	 * Prueft, ob im Startchunk wirklich eine Trial Chamber steht. Bei scanChests werden alle Chunks der
	 * Struktur voll generiert und die Behaelter auf das Item geprueft.
	 */
	public static Chamber inspect(ServerWorld world, ChunkPos startChunk, boolean scanChests, Item wanted) {
		Registry<Structure> registry = world.getRegistryManager().getOrThrow(RegistryKeys.STRUCTURE);
		Structure structure = registry.getOrThrow(StructureKeys.TRIAL_CHAMBERS).value();

		Chunk chunk = world.getChunk(startChunk.x, startChunk.z, ChunkStatus.STRUCTURE_STARTS);
		StructureStart start = chunk.getStructureStart(structure);
		if (start == null || !start.hasChildren()) {
			return null; // an dieser Stelle ist keine Struktur entstanden
		}

		BlockBox box = start.getBoundingBox();
		BlockPos center = box.getCenter();
		List<BlockPos> hits = new ArrayList<>();
		int vaults = 0;

		if (scanChests) {
			for (int cx = box.getMinX() >> 4; cx <= box.getMaxX() >> 4; cx++) {
				for (int cz = box.getMinZ() >> 4; cz <= box.getMaxZ() >> 4; cz++) {
					WorldChunk worldChunk = world.getChunk(cx, cz); // generiert den Chunk komplett
					for (Map.Entry<BlockPos, BlockEntity> e : new ArrayList<>(worldChunk.getBlockEntities().entrySet())) {
						BlockPos pos = e.getKey();
						if (!box.contains(pos)) {
							continue;
						}
						BlockEntity be = e.getValue();
						if (be.getType() == BlockEntityType.VAULT) {
							vaults++;
						}
						if (be instanceof LootableContainerBlockEntity container && containsItem(world, container, pos, wanted)) {
							hits.add(pos.toImmutable());
						}
					}
				}
			}
		}
		return new Chamber(box, center, scanChests, vaults, hits);
	}

	private static boolean containsItem(ServerWorld world, LootableContainerBlockEntity container, BlockPos pos, Item wanted) {
		NbtCompound nbt = container.createNbt(world.getRegistryManager());
		String table = nbt.getString("LootTable", "");

		if (!table.isEmpty()) {
			long seed = nbt.getLong("LootTableSeed", 0L);
			if (seed == 0L) {
				return false; // ohne festen Seed wuerde erst beim Oeffnen gewuerfelt
			}
			Identifier id = Identifier.tryParse(table);
			if (id == null) {
				return false;
			}
			LootTable lootTable = world.getServer().getReloadableRegistries()
					.getLootTable(RegistryKey.of(RegistryKeys.LOOT_TABLE, id));
			LootWorldContext context = new LootWorldContext.Builder(world)
					.add(LootContextParameters.ORIGIN, Vec3d.ofCenter(pos))
					.build(LootContextTypes.CHEST);
			for (ItemStack stack : lootTable.generateLoot(context, seed)) {
				if (stack.isOf(wanted)) {
					return true;
				}
			}
			return false;
		}

		// Kiste wurde schon geoeffnet: tatsaechlichen Inhalt pruefen
		for (int i = 0; i < container.size(); i++) {
			if (container.getStack(i).isOf(wanted)) {
				return true;
			}
		}
		return false;
	}

	public static Item wantedItem() {
		return Items.TRIDENT;
	}
}
