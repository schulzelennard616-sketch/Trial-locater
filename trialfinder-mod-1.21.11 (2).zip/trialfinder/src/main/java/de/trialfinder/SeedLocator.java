package de.trialfinder;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * Berechnet Trial-Chamber-Startchunks nur aus dem Seed (wie Chunkbase), ohne Server-Zugriff.
 * Funktioniert deshalb auch auf Multiplayer-Servern. Die Y-Hoehe ist nur geschaetzt.
 *
 * Platzierungswerte: spacing 32, separation 8, salt 94251327, lineare Verteilung.
 * Im Einzelspieler zeigt das Menue einen Selbsttest, ob diese Berechnung mit dem Spiel uebereinstimmt.
 */
public final class SeedLocator {
	public static final int SPACING = 32;
	public static final int SEPARATION = 8;
	public static final int SALT = 94251327;
	public static final int APPROX_Y = -30;

	private SeedLocator() {}

	public static ChunkPos startChunk(long seed, int regionX, int regionZ) {
		long regionSeed = (long) regionX * 341873128712L + (long) regionZ * 132897987541L + seed + (long) SALT;
		Random random = new Random(regionSeed);
		int bound = SPACING - SEPARATION;
		int dx = random.nextInt(bound);
		int dz = random.nextInt(bound);
		return new ChunkPos(regionX * SPACING + dx, regionZ * SPACING + dz);
	}

	/** Alle Chamber-Startchunks im Umkreis, nach Entfernung zur Position sortiert. */
	public static List<ChunkPos> nearest(long seed, BlockPos origin, int radiusRegions) {
		int regionX = Math.floorDiv(origin.getX() >> 4, SPACING);
		int regionZ = Math.floorDiv(origin.getZ() >> 4, SPACING);

		List<ChunkPos> result = new ArrayList<>();
		for (int dx = -radiusRegions; dx <= radiusRegions; dx++) {
			for (int dz = -radiusRegions; dz <= radiusRegions; dz++) {
				result.add(startChunk(seed, regionX + dx, regionZ + dz));
			}
		}
		result.sort(Comparator.comparingDouble(cp -> {
			double ddx = (cp.x << 4) + 8 - origin.getX();
			double ddz = (cp.z << 4) + 8 - origin.getZ();
			return ddx * ddx + ddz * ddz;
		}));
		return result;
	}
}
