package de.trialfinder;

import net.minecraft.util.math.BlockPos;

public final class WaypointState {
	private static volatile BlockPos target;
	private static volatile String label = "Trial Chamber";
	private static volatile boolean approxY;

	private WaypointState() {}

	public static void set(BlockPos pos, String text) {
		set(pos, text, false);
	}

	public static void set(BlockPos pos, String text, boolean yIsApproximate) {
		target = pos;
		label = text;
		approxY = yIsApproximate;
	}

	public static void clear() {
		target = null;
	}

	public static BlockPos get() {
		return target;
	}

	public static String label() {
		return label;
	}

	public static boolean approxY() {
		return approxY;
	}
}
