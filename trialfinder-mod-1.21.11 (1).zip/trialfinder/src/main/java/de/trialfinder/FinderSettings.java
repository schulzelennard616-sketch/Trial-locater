package de.trialfinder;

/** Einfache Einstellungen (nur im Speicher, gelten bis zum Spielende). */
public final class FinderSettings {
	/** Nur Chambers akzeptieren, in denen eine Kiste mit Trident liegt. */
	public static boolean requireTrident = true;
	/** Suchradius in Strukturregionen (1 Region = 32 Chunks = 512 Bloecke). */
	public static int searchRadiusRegions = 8;
	/** Wie viele Chambers pro Suchlauf maximal komplett gescannt werden. */
	public static int maxChambersPerRun = 8;

	private FinderSettings() {}
}
