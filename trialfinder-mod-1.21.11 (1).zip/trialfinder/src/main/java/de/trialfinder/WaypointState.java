package de.trialfinder;

import net.minecraft.util.math.BlockPos;

public final class WaypointState {
	private static volatile BlockPos target;
	private static volatile String label = "Trial Chamber";

	private WaypointState() {}

	public static void set(BlockPos pos, String text) {
		target = pos;
		label = text;
	}

	public static void clear() {
		target = null;
	}

	public static BlockPos get() {
		return target;
	}

	public static String label() {
		return label;
	}
}
