package de.trialfinder;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

/** Zeigt Pfeil, Entfernung und Koordinaten des Waypoints oben am Bildschirm. */
public final class WaypointHud {
	private static final String[] ARROWS = {
			"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"
	};

	private WaypointHud() {}

	public static void render(DrawContext context, RenderTickCounter tickCounter) {
		BlockPos target = WaypointState.get();
		MinecraftClient mc = MinecraftClient.getInstance();
		if (target == null || mc.player == null) {
			return;
		}

		double dx = target.getX() + 0.5 - mc.player.getX();
		double dz = target.getZ() + 0.5 - mc.player.getZ();
		double dy = target.getY() - mc.player.getY();
		double horizontal = Math.sqrt(dx * dx + dz * dz);

		if (horizontal < 4 && Math.abs(dy) < 6) {
			WaypointState.clear(); // angekommen
			return;
		}

		// Minecraft-Yaw: 0 = Sueden (+Z), positiv = im Uhrzeigersinn (nach rechts)
		float targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
		float diff = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
		int index = Math.floorMod(Math.round(diff / 45f), 8);

		int distance = (int) Math.sqrt(horizontal * horizontal + dy * dy);
		String text = ARROWS[index] + " " + WaypointState.label() + " - " + distance + " m  ("
				+ target.getX() + ", " + target.getY() + ", " + target.getZ() + ")";

		int width = mc.textRenderer.getWidth(text);
		int x = (mc.getWindow().getScaledWidth() - width) / 2;
		context.drawTextWithShadow(mc.textRenderer, Text.literal(text), x, 24, 0xFFFFFFFF);
	}
}
