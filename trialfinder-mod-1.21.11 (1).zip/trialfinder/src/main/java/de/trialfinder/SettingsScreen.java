package de.trialfinder;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class SettingsScreen extends Screen {
	private final Screen parent;

	public SettingsScreen(Screen parent) {
		super(Text.literal("Kisten-Einstellungen"));
		this.parent = parent;
	}

	private static Text filterLabel() {
		return Text.literal("Nur Chambers mit Trident-Kiste: " + (FinderSettings.requireTrident ? "AN" : "AUS"));
	}

	@Override
	protected void init() {
		int x = this.width / 2 - 120;
		int y = this.height / 2 - 20;

		addDrawableChild(ButtonWidget.builder(filterLabel(), b -> {
			FinderSettings.requireTrident = !FinderSettings.requireTrident;
			b.setMessage(filterLabel());
			FinderScreen.resetSession();
		}).dimensions(x, y, 240, 20).build());

		addDrawableChild(ButtonWidget.builder(Text.literal("Zur\u00fcck"), b -> this.client.setScreen(this.parent))
				.dimensions(x, y + 28, 240, 20).build());
	}

	@Override
	public void close() {
		this.client.setScreen(this.parent);
	}
}
