package de.trialfinder;

import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.World;

import java.util.List;

/** Merkt sich Kandidatenliste und Ergebnis, damit "Weitersuchen" dort fortsetzt, wo die Suche stehen blieb. */
public final class SearchSession {
	public volatile ChamberFinder.Chamber result;
	public volatile String status = "";
	public volatile Long worldSeed;
	public volatile BlockPos searchOrigin;

	private List<ChunkPos> candidates;
	private int index;

	public synchronized void reset() {
		result = null;
		candidates = null;
		index = 0;
		status = "";
	}

	/** Laeuft auf dem Server-Thread. */
	public synchronized void step(ServerWorld world, BlockPos origin, boolean requireItem) {
		if (world.getRegistryKey() != World.OVERWORLD) {
			status = "Trial Chambers gibt es nur in der Oberwelt.";
			return;
		}
		worldSeed = world.getSeed();
		searchOrigin = origin;

		if (candidates == null) {
			candidates = ChamberFinder.candidates(world, origin, FinderSettings.searchRadiusRegions);
			index = 0;
		}

		int scanned = 0;
		while (index < candidates.size() && scanned < FinderSettings.maxChambersPerRun) {
			ChunkPos chunk = candidates.get(index++);
			ChamberFinder.Chamber chamber = ChamberFinder.inspect(world, chunk, requireItem, ChamberFinder.wantedItem());
			if (chamber == null) {
				continue;
			}
			scanned++;
			if (!requireItem || !chamber.itemChests().isEmpty()) {
				result = chamber;
				status = requireItem ? "Chamber mit Trident-Kiste gefunden." : "N\u00e4chste Chamber gefunden.";
				return;
			}
		}

		result = null;
		if (index >= candidates.size()) {
			status = "Im Suchradius nichts Passendes gefunden.";
		} else {
			status = scanned + " Chambers gepr\u00fcft, keine passt. \"Weitersuchen\" klicken.";
		}
	}
}
