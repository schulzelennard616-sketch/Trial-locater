# Trial Chamber Finder (Fabric, Minecraft 1.21.11)

Client-Mod fuer den Einzelspieler. Taste **K** (aenderbar unter Steuerung) oeffnet ein Menue:

- zeigt die naechste Trial Chamber mit Koordinaten und Entfernung
- **Waypoint erstellen**: Pfeil, Entfernung und Koordinaten oben am Bildschirm
- **Kisten-Einstellungen**: Filter "nur Chambers mit Trident-Kiste" (AN/AUS)
- **Weitersuchen**: setzt die Suche beim naechsten Kandidaten fort

Seed der Welt: **7356637963557968760** (Neue Welt -> Weitere Weltoptionen -> Seed). Das Menue zeigt an, ob der Seed passt.

## Bauen ueber GitHub (ohne Installation)

1. Neues Repository auf github.com anlegen.
2. Den Inhalt dieses Ordners hochladen (Add file -> Upload files), auch den versteckten Ordner `.github`.
3. Reiter **Actions** oeffnen, Lauf "Build Mod" abwarten (ca. 3-5 Minuten).
4. Im fertigen Lauf unten unter **Artifacts** `trialfinder-mod` herunterladen, die JAR liegt im ZIP.

## Bauen lokal

1. JDK 21 installieren.
2. Auf https://fabricmc.net/develop/template die Vorlage fuer 1.21.11 laden und aus ihr nur
   `gradlew`, `gradlew.bat` und den Ordner `gradle/` in dieses Projekt kopieren
   (oder `gradle wrapper` ausfuehren, falls Gradle installiert ist).
3. Versionen in `gradle.properties` (Loader, Loom, Fabric API) mit https://fabricmc.net/develop abgleichen.
4. `./gradlew build` -> fertige Datei in `build/libs/trialfinder-1.0.0.jar`
   Zum Testen: `./gradlew runClient`
5. Die JAR in den `mods`-Ordner legen (Fabric Loader + Fabric API fuer 1.21.11 noetig).

## Hinweise

- Die Quelltexte wurden ohne Compiler geschrieben. Falls beim Bauen ein Fehler kommt, die Meldung kopieren, dann ist das meist eine kleine Namensanpassung.
- Fuer die Kistensuche werden die Chunks der Chamber komplett generiert (kann kurz ruckeln).
- Waypoint-Anzeige ist aktuell ein HUD-Marker. Der Beam in der Spielwelt kommt als naechster Schritt.
